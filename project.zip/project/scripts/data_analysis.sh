#!/bin/bash

batchid=`cat /home/acadgild/project/logs/current-batch.txt`

LOGFILE=/home/acadgild/project/logs/log_batch_$batchid

echo "Running Spark Script for Data Analysis..." >> $LOGFILE

echo "Exporting analyzed data to Local FS..." >> $LOGFILE

cat /home/acadgild/project/scripts/data_analysis.scala | spark-shell

echo "All Activities Complete..." >> $LOGFILE

echo "Incrementing batchid..." >> $LOGFILE

echo "Incrementing batchid..." >> $LOGFILE

batchid=`expr $batchid +1`

echo -n $batchid > /home/acadgild/project/logs/current-batch.txt
